import { CreateProductUseCase } from "./application/create-product.use-case";

import { InMemoryProductsRepository } from "./test/repositories/in-memory-products-repository";

function main() {
  const inMemoryProductsRepository = new InMemoryProductsRepository();

  const createProductUseCase = new CreateProductUseCase(
    inMemoryProductsRepository
  );

  createProductUseCase.execute({
    name: "Banana",
    price: 10,
  });

  console.log(inMemoryProductsRepository.findMany());
}
