import { Product } from "../entities/product";

export interface ProductsRepository {
  create(product: Product): void;
  save(product: Product): void;
  delete(id: string): void;
  findById(productId: string): Product | null;
  findMany(): Product[];
}
