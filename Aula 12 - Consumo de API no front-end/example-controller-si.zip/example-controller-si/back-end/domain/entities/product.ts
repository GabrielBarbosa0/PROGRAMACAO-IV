import { Entity } from "../entity";

type ProductProps = {
  name: string;
  price: number;
};

export class Product extends Entity<ProductProps> {
  constructor(props: ProductProps, id?: string) {
    super(props);
  }

  get name() {
    return this.props.name;
  }

  set name(name: string) {
    if (name.length > 10) {
      throw new Error("O nome é grande demais");
    }
    this.props.name = name;
  }

  get price() {
    return this.props.price;
  }
}
