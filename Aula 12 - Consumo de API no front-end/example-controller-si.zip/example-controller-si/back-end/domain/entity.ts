export abstract class Entity<T extends object> {
  readonly _id: string;
  public props: T;

  readonly _createAt: Date;
  _updatedAt: Date;

  constructor(props: T, id?: string, createdAt?: Date, updatedAt?: Date) {
    this._id = id ? id : crypto.randomUUID();

    this.props = props;

    this._createAt = createdAt ? createdAt : new Date();
    this._updatedAt = updatedAt ? updatedAt : new Date();
  }

  get id() {
    return this._id;
  }
}
