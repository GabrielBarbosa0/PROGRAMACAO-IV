import { Product } from "../domain/entities/product";
import { ProductsRepository } from "../domain/repositories/products-repository";

import { inMemoryProductsRepository } from "../test/repositories/in-memory-products-repository";

interface FetchProductsUseCaseRequest {}

interface FetchProductsUseCaseResponse {
  products: Product[];
}

export class FetchProductsUseCase {
  constructor(private productsRepository: ProductsRepository) {}

  execute(request: FetchProductsUseCaseRequest): FetchProductsUseCaseResponse {
    const products = this.productsRepository.findMany();

    return {
      products: products,
    };
  }
}
