import { Product } from "../domain/entities/product";

import { ProductsRepository } from "../domain/repositories/products-repository";

interface CreateProductUseCaseRequest {
  name: string;
  price: number;
}

interface CreateProductUseCaseResponse {
  product: Product;
}

export class CreateProductUseCase {
  constructor(private productsRepository: ProductsRepository) {}

  execute(request: CreateProductUseCaseRequest): CreateProductUseCaseResponse {
    const product = new Product({ name: request.name, price: request.price });

    this.productsRepository.create(product);

    return {
      product,
    };
  }
}
