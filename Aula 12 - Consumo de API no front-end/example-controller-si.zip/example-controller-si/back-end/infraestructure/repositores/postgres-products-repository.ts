// src/infra/repositories/postgres-products-repository.ts
import { Product } from "../../domain/entities/product";
import { ProductsRepository } from "../../domain/repositories/products-repository";

import { db } from "../db";

export class PostgresProductsRepository implements ProductsRepository {
  async create(product: Product): Promise<void> {
    await db.query(
      `INSERT INTO products (id, name, description, price, created_at, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [product.id, product.name, product.price]
    );
  }

  async save(product: Product): Promise<void> {
    await db.query(
      `UPDATE products
       SET name = $1, description = $2, price = $3, updated_at = $4
       WHERE id = $5`,
      [product.name, product.price]
    );
  }

  async delete(id: string): Promise<void> {
    await db.query(`DELETE FROM products WHERE id = $1`, [id]);
  }

  async findById(productId: string): Promise<Product | null> {
    const result = await db.query(`SELECT * FROM products WHERE id = $1`, [
      productId,
    ]);

    const row = result.rows[0];

    if (!row) return null;

    return {
      id: row.id,
      name: row.name,
      price: row.price,
    };
  }

  async findMany(): Promise<Product[]> {
    const result = await db.query(
      `SELECT * FROM products ORDER BY created_at DESC`
    );
    return result.rows.map((row) => ({
      id: row.id,
      name: row.name,
      description: row.description,
      price: row.price,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
    }));
  }
}
