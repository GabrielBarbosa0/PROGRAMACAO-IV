// Require the framework and instantiate it

// ESM
import Fastify from "fastify";
import { productsRoutes } from "./controllers/routes";

import cors from "@fastify/cors";

export const api = Fastify({
  logger: true,
});

api.register(cors);

productsRoutes(api); // registra as rotas

// Run the server!
api.listen({ port: 3000, host: "0.0.0.0" }, function (err, address) {
  if (err) {
    api.log.error(err);
    process.exit(1);
  }
  // Server is now listening on ${address}
});
