import { FastifyReply, FastifyRequest } from "fastify";
import { CreateProductUseCase } from "../../application/create-product.use-case";
import { inMemoryProductsRepository } from "../../test/repositories/in-memory-products-repository";

export async function CreateProductController(
  request: FastifyRequest,
  reply: FastifyReply
) {
  const createProductUseCase = new CreateProductUseCase(
    inMemoryProductsRepository
  );

  const { product } = createProductUseCase.execute({
    name: request.body.name,
    price: request.body.price,
  });

  reply.send({ product });
}
