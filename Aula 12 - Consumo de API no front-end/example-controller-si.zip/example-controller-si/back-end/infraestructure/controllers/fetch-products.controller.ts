import { FastifyReply, FastifyRequest } from "fastify";
import { FetchProductsUseCase } from "../../application/fetch-products.use-case";
import { inMemoryProductsRepository } from "../../test/repositories/in-memory-products-repository";

export async function fetchProductsController(
  request: FastifyRequest,
  reply: FastifyReply
) {
  const fetchProductsUseCase = new FetchProductsUseCase(
    inMemoryProductsRepository
  );

  try {
    const { products } = fetchProductsUseCase.execute({});
    console.log(products);

    const mappedProducts = products.map((product) => {
      return {
        id: product.id,
        name: product.props.name,
        price: product.props.price,
        createdAt: product._createAt,
        updatedAt: product._updatedAt,
      };
    });

    reply.send({
      products: mappedProducts,
    });

    // reply.send({
    //   products,
    // });
  } catch (error) {
    console.error(error);
  }
}
