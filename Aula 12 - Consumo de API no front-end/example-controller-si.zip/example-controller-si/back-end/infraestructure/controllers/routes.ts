import { FastifyInstance } from "fastify";
import { api } from "../server";

import { CreateProductController } from "./create-product.controller";
import { fetchProductsController } from "./fetch-products.controller";

// import { fetchProductsController } from "./fetch-products.controller";

export function productsRoutes(api: FastifyInstance) {
  api.post("/products", CreateProductController);
  api.get("/products", fetchProductsController);
}
