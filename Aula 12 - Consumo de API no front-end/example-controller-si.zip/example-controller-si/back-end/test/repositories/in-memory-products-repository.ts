import { Product } from "../../domain/entities/product";
import { ProductsRepository } from "../../domain/repositories/products-repository";

class InMemoryProductsRepository implements ProductsRepository {
  public products: Product[] = [];

  create(product: Product): void {
    this.products.push(product);
  }

  save(product: Product): void {
    const index = this.products.findIndex((p) => p.id === product.id);

    this.products[index] = product;
  }

  delete(id: string): void {
    this.products = this.products.filter((p) => p.id !== id);
  }

  findById(productId: string): Product | null {
    const product = this.products.find((p) => p.id === productId);

    if (!product) {
      return null;
    }

    return product;
  }

  findMany(): Product[] {
    return this.products;
  }
}

const inMemoryProductsRepository = new InMemoryProductsRepository();

export { inMemoryProductsRepository };
